/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.customtasks.agentchat

import android.content.Context
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.dataStoreFile
import com.google.ai.edge.gallery.R
import com.google.ai.edge.gallery.customtasks.common.CustomTask
import com.google.ai.edge.gallery.customtasks.common.CustomTaskDataForBuiltinTask
import com.google.ai.edge.gallery.data.BuiltInTaskId
import com.google.ai.edge.gallery.data.Category
import com.google.ai.edge.gallery.data.Model
import com.google.ai.edge.gallery.data.Task
import com.google.ai.edge.gallery.domain.rag.RagDocumentInfo
import com.google.ai.edge.gallery.proto.McpServers
import com.google.ai.edge.gallery.proto.Skill
import com.google.ai.edge.gallery.ui.llmchat.LlmChatModelHelper
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.tool
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private const val TAG = "AGAgentChatTask"

// The default system prompt for the agent chat task with both skills and MCP tools.
const val DEFAULT_SYSTEM_PROMPT =
  """
  You are an AI assistant that helps users by answering questions and completing tasks using skills and tools. For EVERY new task, request, or question, you MUST execute the following steps in exact order. You MUST NOT skip any steps.

  CRITICAL RULE: You MUST execute all steps silently. Do NOT generate or output any internal thoughts, reasoning, explanations, or intermediate text at ANY step.

  1. EVALUATE AND ROUTE:
     Determine if the request should be handled by a "Skill" (requires loading instructions) or directly by an "MCP Tool".
     - If it is a Skill: Go to Step 2.
     - If it is an MCP Tool: Go to Step 4.
     - If nothing is found, output "No skills or tools found" and stop.

  --- SKILLS ---
  ___SKILLS___

  --- MCP TOOLS ---
  ___TOOLS___

  ==================================================
  FLOW A: SKILL EXECUTION
  ==================================================

  2. Find the most relevant skill from the --- SKILLS --- list. You MUST NOT use `run_intent` or `runMcpTool` under any circumstances at this step.

  3. Use the `load_skill` tool to read its instructions. Follow the skill's instructions exactly to complete the task.
     - You MUST NOT output any intermediate thoughts or status updates. No exceptions!
     - Output ONLY the final result when successful. It should contain a one-sentence summary of the action taken and the final result of the skill.
     - Stop here once Flow A is complete.

  ==================================================
  FLOW B: MCP TOOL DIRECT EXECUTION
  ==================================================

  4. Find the most relevant tool from the --- MCP TOOLS --- list.

  5. Call the `runMcpTool` tool with the following parameters:
     - `toolName`: The name of the tool to run. Use the exact name from the list above. Do not hallucinate the name. Pay attention to casing and plurals.
     - `input`: The input JSON object that matches the tool's expected input schema.

  6. Output ONLY the final result returned by the tool. You MUST NOT output any intermediate thoughts or status updates. No exceptions!
  """

private val DEFAULT_SYSTEM_PROMPT_TRIMMED = DEFAULT_SYSTEM_PROMPT.trimIndent()

// The default system prompt for the agent chat task with only skills.
const val DEFAULT_SYSTEM_PROMPT_SKILLS_ONLY =
  """
  You are an AI assistant that helps users by answering questions and completes tasks using skills. For EVERY new task or request or question, you MUST execute the following steps in exact order. You MUST NOT skip any steps.

  CRITICAL RULE: You MUST execute all steps silently. Do NOT generate or output any internal thoughts, reasoning, explanations, or intermediate text at ANY step.

  1. First, find the most relevant skill from the following list:

  ___SKILLS___

  After this step you MUST go to next step. You MUST NOT use `run_intent` under any circumstances at this step.

  2. If a relevant skill exists, use the `load_skill` tool to read its instructions. You MUST NOT use `run_intent` under any circumstances at this step.

  3. Follow the skill's instructions exactly to complete the task. You MUST NOT output any intermediate thoughts or status updates. No exceptions! Output ONLY the final result when successful. It should contain one-sentence summary of the action taken, and the final result of the skill.

  4. If no relevant skill is found, output "No relevant skills found" and stop.
  """

private val DEFAULT_SYSTEM_PROMPT_SKILLS_ONLY_TRIMMED =
  DEFAULT_SYSTEM_PROMPT_SKILLS_ONLY.trimIndent()

class AgentChatTask @Inject constructor() : CustomTask {
  private val agentTools: AgentTools = AgentToolsImpl()

  override val task: Task =
    Task(
      id = BuiltInTaskId.LLM_AGENT_CHAT,
      // Renamed from "Agent Skills" — this is now the single unified chat entry point on the
      // home screen (Ask Image / Audio Scribe / Mobile Actions / Agent Skills all merged in via
      // the triggers row + image/audio pickers already wired into this screen), not a
      // skills-specific side feature anymore.
      label = "AI Chat",
      category = Category.LLM,
      iconVectorResourceId = R.drawable.agent,
      newFeature = true,
      models = mutableListOf(),
      description =
        "Chat with an on-device LLM — ask about images, transcribe audio, use skills and " +
          "device actions, all in one place",
      shortDescription = "Chat, images, audio, skills & actions",
      docUrl = "https://github.com/google-ai-edge/LiteRT-LM/blob/main/kotlin/README.md",
      sourceCodeUrl =
        "https://github.com/google-ai-edge/gallery/blob/main/Android/src/app/src/main/java/com/google/ai/edge/gallery/customtasks/agentchat/",
      textInputPlaceHolderRes = R.string.text_input_placeholder_llm_chat,
      defaultSystemPrompt = DEFAULT_SYSTEM_PROMPT_TRIMMED,
    )

  override fun initializeModelFn(
    context: Context,
    coroutineScope: CoroutineScope,
    model: Model,
    systemInstruction: Contents?,
    onDone: (String) -> Unit,
  ) {
    val initialSystemPrompt = systemInstruction?.toString() ?: task.defaultSystemPrompt
    coroutineScope.launch(Dispatchers.Default) {
      val unused = model.setupAgentSkillTopK()
      val skillsJob = launch { agentTools.skillManagerViewModel.loadSkills() }
      val mcpJob = launch { agentTools.mcpManagerViewModel.loadMcpServers() }
      skillsJob.join()
      mcpJob.join()

      // Determine base system prompt based on whether MCP tools are enabled.
      val toolsPrompt = agentTools.mcpManagerViewModel.getToolsPrompt()
      val baseSystemPrompt =
        getEffectiveBaseSystemPrompt(initialSystemPrompt, toolsPrompt.isNotEmpty())

      val finalSystemInstruction =
        injectSkillsAndMcpTools(
          baseSystemPrompt = baseSystemPrompt,
          skills = agentTools.skillManagerViewModel.getSelectedSkills(),
          toolsPrompt = toolsPrompt,
        )

      LlmChatModelHelper.initialize(
        context = context,
        model = model,
        taskId = task.id,
        supportImage = true,
        supportAudio = true,
        onDone = onDone,
        systemInstruction = finalSystemInstruction,
        tools = listOf(tool(agentTools)),
        enableConversationConstrainedDecoding = true,
      )
    }
  }

  override fun cleanUpModelFn(
    context: Context,
    coroutineScope: CoroutineScope,
    model: Model,
    onDone: () -> Unit,
  ) {
    val unused = model.cleanupAgentSkillTopK()
    LlmChatModelHelper.cleanUp(model = model, onDone = onDone)
  }

  @Composable
  override fun MainScreen(data: Any) {
    val myData = data as CustomTaskDataForBuiltinTask
    AgentChatScreen(
      task = task,
      modelManagerViewModel = myData.modelManagerViewModel,
      navigateUp = myData.onNavUp,
      agentTools = agentTools,
      initialQuery = myData.initialQuery,
    )
  }
}

@Module
@InstallIn(SingletonComponent::class)
internal object AgentChatTaskModule {
  @Provides
  @IntoSet
  fun provideTask(): CustomTask {
    return AgentChatTask()
  }

  @Provides
  @Singleton
  fun provideMcpServersDataStore(@ApplicationContext context: Context): DataStore<McpServers> {
    return DataStoreFactory.create(
      serializer = McpServersSerializer,
      produceFile = { context.dataStoreFile("mcp_servers.pb") },
    )
  }
}

fun injectSkillsAndMcpTools(
  baseSystemPrompt: String,
  skills: List<Skill>,
  toolsPrompt: String,
  actionsEnabled: Boolean = true,
  ragEnabled: Boolean = true,
  mobileActionsEnabled: Boolean = false,
  // NEW: current RAG index contents, so the model knows what's actually searchable right now
  // instead of discovering it only by calling ragSearch and getting nothing back. Empty by
  // default so callers that don't pass it (if any remain) behave exactly as before.
  ragDocuments: List<RagDocumentInfo> = emptyList(),
): Contents {
  // "Actions" (roadmap term) covers both skills (load_skill) and MCP tools (runMcpTool) —
  // both are tool-calling based, so both get suppressed together when the user turns the
  // Actions trigger off.
  val selectedSkillsNamesAndDescriptions =
    if (!actionsEnabled) {
      ""
    } else {
      skills
        .filter { it.selected }
        .joinToString("\n\n") { skill ->
          "- Skill name: \"${skill.name}\"\n- Description: ${skill.description}"
        }
    }
  val effectiveToolsPrompt = if (actionsEnabled) toolsPrompt else ""

  val systemPrompt =
    if (selectedSkillsNamesAndDescriptions.isBlank() && effectiveToolsPrompt.isBlank()) {
      ""
    } else {
      baseSystemPrompt
        .replace("___SKILLS___", selectedSkillsNamesAndDescriptions)
        .replace("___TOOLS___", effectiveToolsPrompt)
    }

  val gatingText =
    buildModeGatingText(
      actionsEnabled = actionsEnabled,
      ragEnabled = ragEnabled,
      mobileActionsEnabled = mobileActionsEnabled,
    )
  val ragDocumentsText = buildRagDocumentsPromptText(ragEnabled = ragEnabled, documents = ragDocuments)

  val finalPrompt =
    listOf(systemPrompt, gatingText, ragDocumentsText)
      .filter { it.isNotBlank() }
      .joinToString("\n\n")
  Log.d(TAG, "System prompt:\n$finalPrompt")
  return Contents.of(finalPrompt)
}

/**
 * Appends explicit, user-controlled mode instructions (the "triggers" from the interface
 * roadmap) on top of the existing skills/MCP routing prompt above. Additive only — when both
 * flags are true this is a no-op relative to the pre-existing prompt, so behavior for anyone
 * not using the new triggers UI is unchanged.
 */
fun buildModeGatingText(
  actionsEnabled: Boolean,
  ragEnabled: Boolean,
  mobileActionsEnabled: Boolean = false,
): String {
  // Mobile Actions is hard-gated by whether its ToolSet is even added to the session (see
  // resetSessionWithCurrentSkillsAndMcps), not by a prompt instruction, so it doesn't need a
  // branch here — the parameter is accepted for symmetry/future use.
  if (actionsEnabled && ragEnabled) return ""
  return buildString {
      appendLine("--- MODE SETTINGS (user-controlled triggers) ---")
      if (!actionsEnabled) {
        appendLine(
          "Actions: OFF. Do NOT call load_skill, runMcpTool, runJs, or runIntent under any " +
            "circumstances, even if a relevant skill or tool exists. Answer using your own " +
            "knowledge only."
        )
      }
      if (!ragEnabled) {
        appendLine("RAG: OFF. Do NOT call ragSearch, even if documents are indexed.")
      }
    }
    .trimEnd()
}

/**
 * Lists what's actually in the local RAG index right now, so the model can decide WHETHER to
 * call `ragSearch` at all instead of either (a) never calling it because it doesn't know
 * anything is indexed, or (b) calling it speculatively on every turn "just in case". Rebuilt
 * every time the session resets — including on trigger toggles (existing behavior) AND now on
 * document add/remove (see AgentChatScreen.kt's ragUiState.documents LaunchedEffect) — so this
 * never goes stale mid-session the way a one-time system prompt would.
 */
private fun buildRagDocumentsPromptText(ragEnabled: Boolean, documents: List<RagDocumentInfo>): String {
  if (!ragEnabled || documents.isEmpty()) return ""
  return buildString {
    appendLine("--- RAG DOCUMENTS AVAILABLE ---")
    appendLine(
      "The following documents are indexed locally and searchable via ragSearch. Prefer " +
        "calling ragSearch over guessing when a question could relate to one of these:"
    )
    documents.forEach { doc ->
      appendLine("- \"${doc.name}\" (${doc.chunkCount} chunks): ${doc.previewText}")
    }
  }
    .trimEnd()
}

// Check whether the system prompt is the default one.
fun isDefaultSystemPrompt(prompt: String): Boolean {
  return prompt == DEFAULT_SYSTEM_PROMPT_TRIMMED ||
    prompt == DEFAULT_SYSTEM_PROMPT_SKILLS_ONLY_TRIMMED
}

// Returns the effective default system prompt depending on whether MCP tools are enabled.
fun getEffectiveBaseSystemPrompt(currentPrompt: String, hasMcpTools: Boolean): String {
  return if (isDefaultSystemPrompt(currentPrompt)) {
    if (hasMcpTools) DEFAULT_SYSTEM_PROMPT_TRIMMED else DEFAULT_SYSTEM_PROMPT_SKILLS_ONLY_TRIMMED
  } else {
    currentPrompt
  }
}
