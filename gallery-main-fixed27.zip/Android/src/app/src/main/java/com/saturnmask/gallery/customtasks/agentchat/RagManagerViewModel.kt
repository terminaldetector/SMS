/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.saturnmask.gallery.customtasks.agentchat

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.saturnmask.gallery.domain.rag.RagDocumentInfo
import com.saturnmask.gallery.domain.rag.RagEngine
import com.saturnmask.gallery.domain.rag.RagMode
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RagManagerUiState(
  val documents: List<RagDocumentInfo> = emptyList(),
  val importing: Boolean = false,
  // Non-null exactly while `importing` is true. `total == 0` means "still parsing/chunking, no
  // per-chunk progress yet" — the UI should show an indeterminate bar for that brief window and
  // switch to determinate once the first onProgress(0, total) callback lands.
  val importProgress: ImportProgress? = null,
  val error: String? = null,
  // Mode new documents are added under (via the sheet's "Add" button or the chat "+" menu's
  // "Attach file"). Doesn't affect already-indexed documents — see RagDocumentInfo.scope.
  val selectedMode: RagMode = RagMode.STATIC,
) {
  /** Convenience for UI: 0f..1f, or null while progress is still indeterminate. */
  val importFraction: Float?
    get() = importProgress?.let { if (it.total <= 0) null else it.done.toFloat() / it.total }
}

data class ImportProgress(val done: Int, val total: Int)

@HiltViewModel
class RagManagerViewModel
@Inject
constructor(private val ragEngine: RagEngine, @ApplicationContext private val context: Context) :
  ViewModel() {

  private val _uiState = MutableStateFlow(RagManagerUiState())
  val uiState = _uiState.asStateFlow()

  // The current chat's session ID, so dynamic (session-scoped) documents are attributed to the
  // right chat. Set once per composition from AgentChatScreen.kt via setSessionId — a plain var,
  // not a constructor param, because this ViewModel is a Hilt-scoped singleton-per-screen created
  // before the caller knows the session ID.
  private var sessionId: String? = null

  init {
    refresh()
  }

  /** No-ops if [sessionId] hasn't changed, so calling this every recomposition is cheap. */
  fun setSessionId(sessionId: String) {
    if (this.sessionId == sessionId) return
    this.sessionId = sessionId
    refresh()
  }

  fun setMode(mode: RagMode) {
    _uiState.update { it.copy(selectedMode = mode) }
  }

  fun refresh() {
    viewModelScope.launch {
      _uiState.update { it.copy(documents = ragEngine.listDocuments(sessionId = sessionId)) }
    }
  }

  fun importDocument(uri: Uri) {
    viewModelScope.launch {
      val mode = _uiState.value.selectedMode
      _uiState.update { it.copy(importing = true, importProgress = null, error = null) }
      val displayName = queryDisplayName(uri) ?: "document"
      val result =
        ragEngine.addDocument(
          uri = uri,
          displayName = displayName,
          mode = mode,
          sessionId = if (mode == RagMode.DYNAMIC) sessionId else null,
        ) { done, total ->
          // onProgress fires from a background dispatcher (see RagEngineImpl) — StateFlow.update
          // is thread-safe, so no extra dispatching needed here.
          _uiState.update { it.copy(importProgress = ImportProgress(done, total)) }
        }
      result
        .onSuccess { refresh() }
        .onFailure { e -> _uiState.update { it.copy(error = e.message ?: "Import failed") } }
      _uiState.update { it.copy(importing = false, importProgress = null) }
    }
  }

  fun removeDocument(documentId: String) {
    viewModelScope.launch {
      ragEngine.removeDocument(documentId)
      refresh()
    }
  }

  private fun queryDisplayName(uri: Uri): String? {
    return context.contentResolver
      .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
      ?.use { cursor ->
        if (cursor.moveToFirst()) {
          val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          if (idx >= 0) cursor.getString(idx) else null
        } else {
          null
        }
      }
  }
}
