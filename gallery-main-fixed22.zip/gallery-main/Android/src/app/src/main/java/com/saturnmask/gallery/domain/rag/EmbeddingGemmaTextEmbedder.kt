/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.saturnmask.gallery.domain.rag

import java.io.File

private const val TAG = "AGEmbeddingGemma"

/**
 * TEMPORARILY DISABLED (compile-time stub) - see the build error history that led here.
 *
 * The original implementation used com.google.ai.edge.litert:litert:2.1.0's CompiledModel API
 * to run EmbeddingGemma-300M on-device. That dependency conflicts with what's already in this
 * project:
 *  - libs.tflite is Google Play Services TFLite (com.google.android.gms:play-services-tflite-*),
 *    which transitively pulls org.tensorflow:tensorflow-lite-api - litert:2.1.0 bundles
 *    duplicate copies of those same org.tensorflow.lite.* classes (checkDebugDuplicateClasses
 *    failure).
 *  - litertlm-android (already a dependency, backs the chat feature) already ships its own
 *    lib/arm64-v8a/libLiteRt.so - litert:2.1.0 ships another copy of the exact same filename
 *    (mergeDebugNativeLibs failure).
 *
 * Fixing this properly means rewriting model execution against Play Services TFLite's actual API
 * (com.google.android.gms.tflite.java.TfLite.initialize(context) - async, returns a Task,
 * then InterpreterApi.create(...)) instead of the CompiledModel API used here originally. That's
 * a different, non-trivial rewrite on top of the pre-existing uncertainty around this model's
 * exact input/output tensor shapes - stacking two unverified things at once isn't a good idea
 * under time pressure, so this is stubbed out for now rather than shipped half-verified.
 *
 * None of this blocks anything else: FallbackTextEmbedder already exists specifically to
 * degrade to HashingTextEmbedder whenever the neural path isn't available - which, right now,
 * is unconditionally. RAG search still works, just without the semantic-quality upgrade until
 * this is revisited.
 *
 * To properly re-enable: reintroduce model/tokenizer loading here using Play Services TFLite's
 * InterpreterApi, re-add ai.djl.huggingface:tokenizers usage for the SentencePiece tokenizer
 * (that part was fine, no conflict - only the model *runner* needs to change), and verify tensor
 * shapes against the actual downloaded .tflite file via Netron before trusting the output.
 */
class EmbeddingGemmaTextEmbedder(
  private val modelFile: File,
  private val tokenizerFile: File,
  override val dimension: Int = 768,
) : TextEmbedder {

  override val id: String = "embeddinggemma-300m-disabled"

  override suspend fun embed(text: String, kind: EmbeddingKind): FloatArray {
    error(
      "Neural embedder is temporarily disabled (dependency conflict - see class doc comment). " +
        "FallbackTextEmbedder should have caught this and used HashingTextEmbedder instead."
    )
  }
}
