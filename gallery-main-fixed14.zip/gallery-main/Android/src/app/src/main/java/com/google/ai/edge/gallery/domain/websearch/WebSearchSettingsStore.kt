/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.domain.websearch

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "AGWebSearchSettings"
private const val PREFS_NAME = "web_search_settings"
private const val KEY_API_KEY = "brave_api_key"

/**
 * Stores the user's own Brave Search API key. This is a per-user, self-supplied credential (like
 * pointing the app at your own OpenAI key would be) — nothing is bundled or shared, and the app
 * makes zero web-search calls until the user pastes a key into the settings sheet.
 *
 * Uses [EncryptedSharedPreferences] since this is a secret; falls back to plain [SharedPreferences]
 * only if key-store-backed encryption is unavailable on the device (some older/custom ROMs), which
 * is still strictly better than crashing the settings screen — noted via a log warning so it's not
 * a silent security downgrade.
 */
@Singleton
class WebSearchSettingsStore @Inject constructor(@ApplicationContext context: Context) {

  private val prefs: SharedPreferences =
    runCatching {
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
          context,
          PREFS_NAME,
          masterKey,
          EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
          EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
      }
      .getOrElse { e ->
        Log.w(TAG, "EncryptedSharedPreferences unavailable, storing API key unencrypted", e)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      }

  fun getApiKey(): String? = prefs.getString(KEY_API_KEY, null)?.takeIf { it.isNotBlank() }

  fun setApiKey(key: String) {
    prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
  }

  fun clearApiKey() {
    prefs.edit().remove(KEY_API_KEY).apply()
  }

  fun hasApiKey(): Boolean = !getApiKey().isNullOrBlank()
}
