/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.domain.websearch

/**
 * External web search, used to ground the agent when local RAG / model knowledge isn't enough.
 *
 * Deliberately provider-agnostic (mirrors [com.google.ai.edge.gallery.domain.rag.RagEngine]'s
 * shape): swap [BraveWebSearchEngine] for a different backend by changing one `@Binds` line in
 * [WebSearchEngineModule] — nothing else in the app needs to know which provider is behind it.
 */
interface WebSearchEngine {
  /**
   * Runs a web search for [query]. Returns [Result.failure] on network errors, missing/invalid
   * API key, or a non-2xx response — callers (the agent tool) are expected to surface that as a
   * readable error to the model rather than crash.
   */
  suspend fun search(query: String, maxResults: Int = 5): Result<List<WebSearchResult>>
}

data class WebSearchResult(val title: String, val url: String, val snippet: String)
