/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.domain.rag

import android.content.Context
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.EntryPoint
import java.io.File
import javax.inject.Qualifier
import javax.inject.Singleton

/**
 * Standard Hilt binding: makes the [RagEngine] singleton injectable into Hilt-aware classes
 * (e.g. [RagManagerViewModel]).
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RagEngineModule {
  @Binds abstract fun bindRagEngine(impl: RagEngineImpl): RagEngine
}

/**
 * [AgentToolsImpl] is NOT constructed by Hilt (see `AgentChatTaskModule.kt`:
 * `private val agentTools: AgentTools = AgentToolsImpl()`), so it can't use field/constructor
 * injection. This entry point lets it pull the *same* singleton [RagEngine] instance that
 * [RagManagerViewModel] uses, so documents added via the UI are immediately visible to the
 * `ragSearch` tool and vice versa.
 */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface RagEngineEntryPoint {
  fun ragEngine(): RagEngine
}

fun ragEngineFrom(context: android.content.Context): RagEngine =
  EntryPointAccessors.fromApplication(
      context.applicationContext,
      RagEngineEntryPoint::class.java,
    )
    .ragEngine()

// ---------------------------------------------------------------------------------------------
// Everything below is new (neural embedder pass) — see TextEmbedder.kt / EmbeddingGemmaTextEmbedder.kt
// / FallbackTextEmbedder.kt / HashingTextEmbedder.kt for the implementations these bind.
// ---------------------------------------------------------------------------------------------

@Qualifier @Retention(AnnotationRetention.BINARY) annotation class EmbeddingModelFile

@Qualifier @Retention(AnnotationRetention.BINARY) annotation class EmbeddingTokenizerFile

/**
 * Where the (large, license-gated, not bundled in the APK) EmbeddingGemma files live once
 * downloaded. Points at `context.filesDir/rag_models/` for a first cut — wiring an actual
 * download flow through ModelManagerViewModel (like the chat models already do) is a good
 * follow-up, tracked separately, not done here.
 */
@Module
@InstallIn(SingletonComponent::class)
object RagEmbeddingFilesModule {
  @Provides
  @EmbeddingModelFile
  fun provideEmbeddingModelFile(@ApplicationContext context: Context): File =
    File(context.filesDir, "rag_models/embeddinggemma-300M_seq256_mixed-precision.tflite")

  @Provides
  @EmbeddingTokenizerFile
  fun provideEmbeddingTokenizerFile(@ApplicationContext context: Context): File =
    File(context.filesDir, "rag_models/sentencepiece.model")

  @Provides
  @Singleton
  fun provideEmbeddingGemmaTextEmbedder(
    @EmbeddingModelFile modelFile: File,
    @EmbeddingTokenizerFile tokenizerFile: File,
  ): EmbeddingGemmaTextEmbedder = EmbeddingGemmaTextEmbedder(modelFile, tokenizerFile)
}

/**
 * The active [TextEmbedder]: [FallbackTextEmbedder] wraps the neural embedder and transparently
 * degrades to [HashingTextEmbedder] if the model files above aren't present yet (or fail to
 * load). This is the ONLY line to change if you want to swap embedders again later.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class TextEmbedderModule {
  @Binds abstract fun bindTextEmbedder(impl: FallbackTextEmbedder): TextEmbedder
}
