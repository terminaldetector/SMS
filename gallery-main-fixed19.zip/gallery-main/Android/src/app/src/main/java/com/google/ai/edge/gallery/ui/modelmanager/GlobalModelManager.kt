/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.ui.modelmanager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.NoteAdd
import androidx.compose.material.icons.automirrored.rounded.ListAlt
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import com.google.ai.edge.gallery.R
import com.google.ai.edge.gallery.data.Model
import com.google.ai.edge.gallery.data.Task
import com.google.ai.edge.gallery.data.supportModelBenchmark
import com.google.ai.edge.gallery.proto.ImportedModel
import com.google.ai.edge.gallery.ui.common.buildTrackableUrlAnnotatedString
import com.google.ai.edge.gallery.ui.common.modelitem.ModelItem
import com.google.ai.edge.gallery.ui.common.tos.TosViewModel
import kotlin.text.endsWith
import kotlin.text.lowercase
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val TAG = "AGGlobalMM"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalModelManager(
  viewModel: ModelManagerViewModel,
  navigateUp: () -> Unit,
  onModelSelected: (Task, Model) -> Unit,
  onBenchmarkClicked: (Model) -> Unit,
  modifier: Modifier = Modifier,
  tosViewModel: TosViewModel? = null,
) {
  val uiState by viewModel.uiState.collectAsState()
  val builtInModels = remember { mutableStateListOf<Model>() }
  val importedModels = remember { mutableStateListOf<Model>() }
  var showImportModelSheet by remember { mutableStateOf(false) }
  var showHuggingFaceUrlDialog by remember { mutableStateOf(false) }
  var huggingFaceUrlInput by remember { mutableStateOf("") }
  var showUnsupportedModelDialog by remember { mutableStateOf(false) }
  var unsupportedModelErrorMessage by remember { mutableStateOf("") }
  val selectedLocalModelFileUri = remember { mutableStateOf<Uri?>(null) }
  val selectedImportedModelInfo = remember { mutableStateOf<ImportedModel?>(null) }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var showImportDialog by remember { mutableStateOf(false) }
  var showImportingDialog by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  val snackbarHostState = remember { SnackbarHostState() }
  val modelItemExpandedStates = remember { mutableStateMapOf<String, Boolean>() }

  val promoId = "gm4_banner"
  var showPromo by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) {
    showPromo = !viewModel.dataStoreRepository.hasViewedPromo(promoId = promoId)
  }

  val filePickerLauncher: ActivityResultLauncher<Intent> =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
      if (result.resultCode == android.app.Activity.RESULT_OK) {
        result.data?.data?.let { uri ->
          validateAndProcessModelUri(
            uri = uri,
            context = context,
            isWebImport = false,
            onUnsupportedModelError = { errorMessage ->
              unsupportedModelErrorMessage = errorMessage
              showUnsupportedModelDialog = true
            },
            onValidModelUri = { validUri ->
              selectedLocalModelFileUri.value = validUri
              showImportDialog = true
            },
          )
        } ?: run { Log.d(TAG, "No file selected or URI is null.") }
      } else {
        Log.d(TAG, "File picking cancelled.")
      }
    }

  LaunchedEffect(uiState.modelImportingUpdateTrigger) {
    val allowlistModels = viewModel.allowlistModels
    val allowlistOrderMap = allowlistModels.withIndex().associate { it.value.name to it.index }

    val sortedModels =
      viewModel
        .getAllModels()
        // Filter to include only top-level models (those without a parent).
        .filter { it.parentModelName.isNullOrEmpty() }
        .sortedWith(
          compareBy<Model> { model ->
              // Sort by the index in allowlistModels. Models not in the allowlist come last.
              allowlistOrderMap[model.name] ?: Int.MAX_VALUE
            }
            .thenBy { model ->
              // If not in the allowlist, sort by their names.
              model.name
            }
        )
    builtInModels.clear()
    builtInModels.addAll(sortedModels.filter { !it.imported })
    importedModels.clear()
    importedModels.addAll(sortedModels.filter { it.imported })
  }

  // Calculate model variants by grouping models with a parentModelName.
  val modelVariants by
    remember(uiState.modelImportingUpdateTrigger) {
      derivedStateOf {
        val allModels = uiState.tasks.flatMap { it.models }.distinct()
        allModels.filter { it.parentModelName != null }.groupBy { it.parentModelName!! }
      }
    }

  // AgentChatTask (LLM_AGENT_CHAT) is the only registered CustomTask left, so a model is never in
  // more than one task's model list — no "which use case?" picker needed, just go straight there.
  val handleClickModel: (Model) -> Unit = { model ->
    val tasks = viewModel.uiState.value.tasks
    val task = tasks.firstOrNull { task -> task.models.any { it.name == model.name } }
    if (task != null) {
      onModelSelected(task, model)
    }
  }

  // Handle system's edge swipe.
  BackHandler { navigateUp() }

  Scaffold(
    modifier = modifier,
    topBar = {
      CenterAlignedTopAppBar(
        title = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Icon(
                Icons.AutoMirrored.Rounded.ListAlt,
                modifier = Modifier.size(20.dp),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text =
                  "${stringResource(R.string.drawer_models_label)} (${builtInModels.size + importedModels.size})",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
              )
            }
          }
        },
        // The "action" component at the right.
        actions = {
          IconButton(onClick = { navigateUp() }) {
            Icon(
              imageVector = Icons.Rounded.Close,
              contentDescription = stringResource(R.string.cd_close_icon),
              tint = MaterialTheme.colorScheme.onSurface,
            )
          }
        },
        modifier = modifier,
      )
    },
    floatingActionButton = {
      // A floating action button to show "import model" bottom sheet.
      val cdImportModelFab = stringResource(R.string.cd_import_model_button)
      SmallFloatingActionButton(
        onClick = { showImportModelSheet = true },
        containerColor = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.semantics { contentDescription = cdImportModelFab },
      ) {
        Icon(Icons.Filled.Add, contentDescription = null)
      }
    },
  ) { innerPadding ->
    Box() {
      LazyColumn(
        modifier =
          Modifier.background(MaterialTheme.colorScheme.surfaceContainer)
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = innerPadding.calculateTopPadding()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding =
          PaddingValues(top = 16.dp, bottom = innerPadding.calculateBottomPadding() + 80.dp),
      ) {
        item(key = "promo") {
          AnimatedVisibility(
            visible = showPromo,
            enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 2 }) + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
          ) {
            PromoBannerGm4(
              onDismiss = {
                showPromo = false
                viewModel.dataStoreRepository.addViewedPromoId(promoId = promoId)
              }
            )
          }
        }

        items(builtInModels) { model ->
          val expanded = modelItemExpandedStates.getOrDefault(model.name, true)
          ModelItem(
            model = model,
            modelVariants = modelVariants.getOrDefault(model.name, listOf()),
            task = null,
            modelManagerViewModel = viewModel,
            onModelClicked = handleClickModel,
            onBenchmarkClicked = onBenchmarkClicked,
            expanded = expanded,
            showBenchmarkButton = model.supportModelBenchmark,
            onExpanded = { modelItemExpandedStates[model.name] = it },
            tosViewModel = tosViewModel,
          )
        }

        // Imported models.
        if (importedModels.isNotEmpty()) {
          item(key = "imported_models_label") {
            Text(
              stringResource(R.string.model_list_imported_models_title),
              color = MaterialTheme.colorScheme.onSurface,
              style = MaterialTheme.typography.labelLarge,
              modifier = Modifier.padding(horizontal = 16.dp).padding(top = 32.dp, bottom = 8.dp),
            )
          }
        }
        items(importedModels, key = { it.name }) { model ->
          ModelItem(
            model = model,
            task = null,
            modelManagerViewModel = viewModel,
            onModelClicked = handleClickModel,
            onBenchmarkClicked = onBenchmarkClicked,
            expanded = true,
            showBenchmarkButton = model.supportModelBenchmark,
            tosViewModel = tosViewModel,
          )
        }
      }

      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.align(alignment = Alignment.BottomCenter).padding(bottom = 32.dp),
      )

      // Gradient overlay at the bottom.
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(innerPadding.calculateBottomPadding())
            .background(
              Brush.verticalGradient(
                colors = listOf(Color.Transparent, MaterialTheme.colorScheme.surfaceContainer)
              )
            )
            .align(Alignment.BottomCenter)
      )
    }
  }

  // Import model bottom sheet.
  if (showImportModelSheet) {
    ModalBottomSheet(onDismissRequest = { showImportModelSheet = false }, sheetState = sheetState) {
      Text(
        "Import model",
        style = MaterialTheme.typography.titleLarge,
        modifier = Modifier.padding(vertical = 4.dp, horizontal = 16.dp),
      )
      Text(
        stringResource(R.string.import_model_terms_subtitle),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
      )
      val cbImportFromLocalFile = stringResource(R.string.cd_import_model_from_local_file_button)
      Box(
        modifier =
          Modifier.clickable {
              scope.launch {
                // Give it sometime to show the click effect.
                delay(200)
                showImportModelSheet = false

                // Show file picker.
                val intent =
                  Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    // Single select.
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                  }
                filePickerLauncher.launch(intent)
              }
            }
            .semantics {
              role = Role.Button
              contentDescription = cbImportFromLocalFile
            }
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.fillMaxWidth().padding(16.dp),
        ) {
          Icon(Icons.AutoMirrored.Outlined.NoteAdd, contentDescription = null)
          Text("From local model file", modifier = Modifier.clearAndSetSemantics {})
        }
      }
      val cdImportFromHuggingFace = stringResource(R.string.cd_import_model_from_hugging_face)
      Box(
        modifier =
          Modifier.clickable {
              scope.launch {
                delay(200)
                showImportModelSheet = false
                showHuggingFaceUrlDialog = true
              }
            }
            .semantics {
              role = Role.Button
              contentDescription = cdImportFromHuggingFace
            }
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.fillMaxWidth().padding(16.dp),
        ) {
          Icon(Icons.AutoMirrored.Outlined.NoteAdd, contentDescription = null)
          Text(
            stringResource(R.string.import_model_from_hugging_face),
            modifier = Modifier.clearAndSetSemantics {},
          )
        }
      }
    }
  }

  // Import dialog
  if (showImportDialog) {
    selectedLocalModelFileUri.value?.let { uri ->
      ModelImportDialog(
        uri = uri,
        onDismiss = { showImportDialog = false },
        onDone = { info ->
          selectedImportedModelInfo.value = info
          showImportDialog = false
          showImportingDialog = true
        },
      )
    }
  }

  // Importing in progress dialog.
  if (showImportingDialog) {
    selectedLocalModelFileUri.value?.let { uri ->
      selectedImportedModelInfo.value?.let { info ->
        ModelImportingDialog(
          uri = uri,
          info = info,
          onDismiss = { showImportingDialog = false },
          onDone = {
            viewModel.addImportedLlmModel(info = it)
            showImportingDialog = false

            // Show a snack bar for successful import.
            scope.launch { snackbarHostState.showSnackbar("Model imported successfully") }
          },
        )
      }
    }
  }

  // Alert dialog for unsupported model.
  if (showUnsupportedModelDialog) {
    AlertDialog(
      icon = {
        Icon(
          Icons.Rounded.Error,
          contentDescription = stringResource(R.string.cd_error),
          tint = MaterialTheme.colorScheme.error,
        )
      },
      onDismissRequest = { showUnsupportedModelDialog = false },
      title = { Text(stringResource(R.string.unsupported_model_title)) },
      text = { Text(unsupportedModelErrorMessage) },
      confirmButton = {
        Button(onClick = { showUnsupportedModelDialog = false }) {
          Text(stringResource(R.string.ok))
        }
      },
    )
  }

  if (showHuggingFaceUrlDialog) {
    AlertDialog(
      onDismissRequest = { showHuggingFaceUrlDialog = false },
      title = { Text(stringResource(R.string.import_from_hugging_face_title)) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            buildAnnotatedString {
              append(stringResource(R.string.enter_hugging_face_url))
              append(
                buildTrackableUrlAnnotatedString(
                  url = stringResource(R.string.enter_hugging_face_url_example_link),
                  linkText = stringResource(R.string.enter_hugging_face_url_example_link),
                )
              )
            }
          )
          OutlinedTextField(
            value = huggingFaceUrlInput,
            onValueChange = { huggingFaceUrlInput = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.hugging_face_url_placeholder)) },
            singleLine = true,
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val url = huggingFaceUrlInput.trim()
            if (url.isNotEmpty()) {
              showHuggingFaceUrlDialog = false
              val uri = url.toUri()
              validateAndProcessModelUri(
                uri = uri,
                context = context,
                isWebImport = true,
                onUnsupportedModelError = { errorMessage ->
                  unsupportedModelErrorMessage = errorMessage
                  showUnsupportedModelDialog = true
                },
                onValidModelUri = { validUri ->
                  selectedLocalModelFileUri.value = validUri
                  showImportDialog = true
                },
              )
            }
          }
        ) {
          Text(stringResource(R.string.next))
        }
      },
      dismissButton = {
        TextButton(onClick = { showHuggingFaceUrlDialog = false }) {
          Text(stringResource(R.string.cancel))
        }
      },
    )
  }
}

private fun validateAndProcessModelUri(
  uri: Uri,
  context: Context,
  isWebImport: Boolean,
  onUnsupportedModelError: (String) -> Unit,
  onValidModelUri: (Uri) -> Unit,
) {
  val fileName = getFileName(context = context, uri = uri)
  Log.d(TAG, "Validating URI: $uri, fileName: $fileName, isWebImport: $isWebImport")
  val hasValidExtension =
    if (isWebImport) {
      fileName != null && fileName.endsWith(".litertlm")
    } else {
      fileName != null && (fileName.endsWith(".task") || fileName.endsWith(".litertlm"))
    }

  if (!hasValidExtension) {
    onUnsupportedModelError(getErrorMessage(context, R.string.unsupported_file_type_error))
  } else if (fileName != null && fileName.lowercase().contains("-web")) {
    onUnsupportedModelError(getErrorMessage(context, R.string.unsupported_web_model_error))
  } else {
    onValidModelUri(uri)
  }
}

private fun getErrorMessage(context: Context, resId: Int): String {
  return context.getString(resId)
}

// Helper function to get the file name from a URI
private fun getFileName(context: Context, uri: Uri): String? {
  if (uri.scheme == "content") {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
      if (cursor.moveToFirst()) {
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (nameIndex != -1) {
          return cursor.getString(nameIndex)
        }
      }
    }
  } else if (uri.scheme == "file" || uri.scheme == "http" || uri.scheme == "https") {
    return uri.lastPathSegment
  }
  return null
}
