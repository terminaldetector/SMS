/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.customtasks.agentchat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.ai.edge.gallery.domain.rag.RagDocumentInfo

/**
 * Lets the user add documents (plain text / markdown for now — extend the MIME type filter
 * below and [com.google.ai.edge.gallery.domain.rag.RagEngineImpl.addDocument] to support more
 * formats such as PDF/DOCX) to the local RAG index, and remove them.
 *
 * Wire-up is intentionally the same shape as [SkillManagerBottomSheet] / [McpManagerBottomSheet]
 * so it drops into `AgentChatScreen.kt` the same way (see integration guide).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RagManagerBottomSheet(onDismiss: () -> Unit, viewModel: RagManagerViewModel = hiltViewModel()) {
  val uiState by viewModel.uiState.collectAsState()

  val pickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      uri?.let { viewModel.importDocument(it) }
    }

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(modifier = Modifier.padding(20.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(text = "RAG documents", style = MaterialTheme.typography.titleMedium)
        Button(
          onClick = {
            pickerLauncher.launch(
              arrayOf(
                "text/plain",
                "text/markdown",
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/epub+zip",
              )
            )
          },
          enabled = !uiState.importing,
        ) {
          Icon(Icons.Outlined.UploadFile, contentDescription = null)
          androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(start = 4.dp))
          Text("Add")
        }
      }

      uiState.error?.let { error ->
        Text(
          text = error,
          color = MaterialTheme.colorScheme.error,
          style = MaterialTheme.typography.bodySmall,
          modifier = Modifier.padding(top = 8.dp),
        )
      }

      if (uiState.importing) {
        ImportProgressIndicator(
          fraction = uiState.importFraction,
          progress = uiState.importProgress,
          modifier = Modifier.padding(top = 12.dp),
        )
      }

      HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

      if (uiState.documents.isEmpty() && !uiState.importing) {
        Text(
          text = "No documents indexed yet. Add a .txt, .md, .pdf, .docx, or .epub file to enable RAG search.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      } else {
        LazyColumn {
          items(uiState.documents, key = { it.id }) { doc ->
            RagDocumentRow(doc = doc, onRemove = { viewModel.removeDocument(doc.id) })
          }
        }
      }
    }
  }
}

/**
 * A real, determinate progress bar once chunk-level progress is available; falls back to an
 * indeterminate bar for the brief window before the first chunk finishes (parsing a huge PDF, or
 * a neural embedder's one-time model load — see [EmbeddingGemmaTextEmbedder.ensureInitialized]
 * from the earlier embedder pass — can both take a moment before chunk 1/N is even reported).
 */
@Composable
private fun ImportProgressIndicator(
  fraction: Float?,
  progress: ImportProgress?,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier.fillMaxWidth()) {
    if (fraction != null) {
      val animatedFraction by animateFloatAsState(targetValue = fraction, label = "importProgress")
      LinearProgressIndicator(
        progress = { animatedFraction },
        modifier = Modifier.fillMaxWidth(),
      )
      Text(
        text = "Indexing… ${progress?.done ?: 0}/${progress?.total ?: 0} chunks",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp),
      )
    } else {
      LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
      Text(
        text = "Reading document…",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp),
      )
    }
  }
}

@Composable
private fun RagDocumentRow(doc: RagDocumentInfo, onRemove: () -> Unit) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column {
      Text(text = doc.name, style = MaterialTheme.typography.bodyLarge)
      Text(
        text = "${doc.chunkCount} chunks · ${doc.sizeBytes / 1024} KB",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
    IconButton(onClick = onRemove) {
      Icon(Icons.Outlined.Delete, contentDescription = "Remove ${doc.name}")
    }
  }
}
