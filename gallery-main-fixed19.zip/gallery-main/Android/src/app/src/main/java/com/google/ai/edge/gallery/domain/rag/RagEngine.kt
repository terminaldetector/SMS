/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.domain.rag

import android.net.Uri

/**
 * Local, on-device RAG (retrieval-augmented generation) engine.
 *
 * All state is persisted to app-private storage (`filesDir/rag_index.json`) so documents survive
 * process death.
 */
interface RagEngine {

  /**
   * Reads [uri], chunks it, embeds every chunk, and persists it under [displayName].
   *
   * [onProgress] is called after each chunk is embedded — `(chunksDone, chunksTotal)` — so the UI
   * can show a real progress bar instead of an indeterminate spinner. Embedding is the slow part
   * (especially with a neural [TextEmbedder] vs. the hashing fallback), so per-chunk granularity
   * is what actually matters here; chunking/parsing itself is comparatively instant. Defaults to
   * a no-op so existing call sites don't need to change.
   */
  suspend fun addDocument(
    uri: Uri,
    displayName: String,
    onProgress: (chunksDone: Int, chunksTotal: Int) -> Unit = { _, _ -> },
  ): Result<RagDocumentInfo>

  /** Removes a previously added document and all of its chunks from the index. */
  suspend fun removeDocument(documentId: String)

  /** Wipes the entire index. */
  suspend fun clear()

  /** Lists all indexed documents (without their chunk contents, just metadata). */
  suspend fun listDocuments(): List<RagDocumentInfo>

  /** Returns the [topK] most similar chunks to [query] across all indexed documents. */
  suspend fun search(query: String, topK: Int = 5): List<RagSearchResult>
}

data class RagDocumentInfo(
  val id: String,
  val name: String,
  val chunkCount: Int,
  val sizeBytes: Long,
  val addedAtMillis: Long,
  /**
   * First ~150 characters of the document's first chunk, whitespace-collapsed. Used to give the
   * model (and the UI) a rough sense of what's in a document without a full RAG search or a
   * separate summarization pass — see the "RAG DOCUMENTS AVAILABLE" section this feeds in
   * AgentChatTaskModule.kt.
   */
  val previewText: String,
)

data class RagSearchResult(
  val documentId: String,
  val documentName: String,
  val chunkIndex: Int,
  val text: String,
  /** Cosine similarity in [0, 1], 1 = identical direction. */
  val similarity: Float,
)
