/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.domain.rag

import android.util.Log
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "AGFallbackEmbedder"

/**
 * Tries [primary] (the neural embedder); if it's not ready — model not downloaded yet, OOM,
 * unsupported device, whatever — silently falls back to [fallback] (the hashing embedder) so RAG
 * never breaks, it just degrades in quality. Once [primary] fails it stops retrying for the rest
 * of the process lifetime, to avoid retrying a doomed model load on every single chunk.
 *
 * [id] reflects whichever embedder actually served the *last* call, so [RagEngineImpl] can detect
 * a dimension mismatch against the persisted index. In practice you generally want to check
 * [RagEngineImpl] reindex status via [RagDocumentInfo] rather than poll this directly.
 */
@Singleton
class FallbackTextEmbedder
@Inject
constructor(
  private val primary: EmbeddingGemmaTextEmbedder,
  private val fallback: HashingTextEmbedder,
) : TextEmbedder {

  @Volatile private var primaryUnavailable = false

  // Dimension is fixed at construction time so callers (RagEngineImpl) can size things up front.
  // If the neural embedder later turns out to be unavailable, embed() still returns a vector of
  // this size (fallback's dimension differs — see the padding/truncation note in embed()).
  override val dimension: Int = primary.dimension
  override val id: String = if (primaryUnavailable) fallback.id else primary.id

  override suspend fun embed(text: String, kind: EmbeddingKind): FloatArray {
    if (!primaryUnavailable) {
      try {
        return primary.embed(text, kind)
      } catch (t: Throwable) {
        Log.w(TAG, "Neural embedder unavailable, falling back to hashing embedder", t)
        primaryUnavailable = true
      }
    }
    val raw = fallback.embed(text, kind)
    // Pad/truncate so the vector always matches `dimension`, keeping RagEngineImpl agnostic to
    // which backend actually served the request. Truncating the hashing vector loses some of its
    // (already weak) signal; this only matters while the neural model is unavailable.
    return when {
      raw.size == dimension -> raw
      raw.size > dimension -> raw.copyOf(dimension)
      else -> raw.copyOf(dimension) // zero-padded
    }
  }
}
